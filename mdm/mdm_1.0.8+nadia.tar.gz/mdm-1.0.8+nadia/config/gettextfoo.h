/* DO NOT CHANGE HEADER FILE BY HAND! CHANGE THE extract-shell.sh */
/* SCRIPT THIS IS GENERATED.  ADD A CHANGELOG ENTRY IF YOU MODIFY */
/* THIS SCRIPT.                                                   */
/* ALWAYS ADD A CHANGELOG OR I WILL PERSONALLY KICK YOUR ASS! */
const char *foo = N_("Failed to start the X server (your graphical interface).  It is likely that it is not set up correctly.  You will need to log in on a console and reconfigure the X server.  Then restart MDM.");
const char *foo = N_("Would you like to try to configure the X server?  Note that you will need the root password for this.");
const char *foo = N_("Please type in the root (privileged user) password.");
const char *foo = N_("Trying to restart the X server.");
const char *foo = N_("The X server is now disabled.  Restart MDM when it is configured correctly.");
const char *foo = N_("Failed to start the X server (your graphical interface).  It is likely that it is not set up correctly.  Would you like to view the X server output to diagnose the problem?");
const char *foo = N_("Would you like to view the detailed X server output as well?");
const char *foo = N_("Failed to start the X server (your graphical interface).  It seems that the pointer device (your mouse) is not set up correctly.  Would you like to view the X server output to diagnose the problem?");
const char *foo = N_("Would you like to try to configure the mouse?  Note that you will need the root password for this.");
const char *foo = N_("Would you like to try to configure the mouse?  Note that you will need the root password for this.");
const char *foo = N_("System has no Xclients file, so starting a failsafe xterm session.  Windows will have focus only if the mouse pointer is above them.  To get out of this mode type 'exit' in the window.");
const char *foo = N_("Failed to start the session, so starting a failsafe xterm session.  Windows will have focus only if the mouse pointer is above them.  To get out of this mode type 'exit' in the window.");
